let cart = localStorage.getItem("products");
cart = JSON.parse(cart);

if (cart === null) {
  console.log("je suis vide");
}

console.log(cart);

for (let item of cart) {
  console.table(item.id);

  fetch("http://localhost:3000/api/products/" + item.id)
    .then(function (res) {
      if (res.ok) {
        return res.json();
      }
    })
    .then(function (product) {
      document.getElementById('cart__items').innerHTML +=
      `<article class="cart__item" data-id="{product-ID}" data-color="{product-color}"></article>
      <img src="${product.imageUrl}" alt="${product.altTxt}">
      <h3 class="${product.name}">${product.name}</h3>
      <p class="cart__item__content">${product.description}</p>`
      console.log(product)

    });
}

